const form = document.getElementById('signup-form');
form.addEventListener('submit', async (e) => {
  e.preventDefault();
  const username = document.getElementById('username').value;
  const email = document.getElementById('email').value;
  const role = document.getElementById('role').value;

  const { createClient } = supabase;
  const supabaseUrl = 'https://wejcgylojzxxgftzjeew.supabase.co';
  const supabaseKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...'; // (shortened)
  const supabaseClient = createClient(supabaseUrl, supabaseKey);

  const { data, error } = await supabaseClient.from('PLATFORMS').insert([{ username, email, role }]);

  if (error) {
    alert('Error: ' + error.message);
  } else {
    alert('Account created successfully!');
    form.reset();
  }
});
